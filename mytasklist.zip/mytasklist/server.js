var express = require ('express');
var path = require( 'path');
var bodyParser = require ('body-parser');

var index = require ('./routes/index');
var tasks = require ('./routes/tasks');

var mongojs = require('mongojs');
var db = mongojs('mydb', ['users','portfolios']);

var port = 3000;

var app = express();
/*
var logger = function(req,res,next)
{
    console.log('logging...');
    next();
}

app.use(logger);
*/
//view engine
app.set('views',path.join(__dirname,'views'));
app.set ('view engine','ejs');
app.engine('html',require('ejs').renderFile);
//set static folder
app.use(express.static(path.join(__dirname,'client')));
//body parser mw
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

app.get('/',function(req,res)
    {
        db.users.find(function (err, docs) 
        {
            res.render('index.ejs');
        }
)
        
    }
    );
app.use('/Registeration',function(req,res)
{
    var newUser =
    {
        user: req.body.uname,
        pass: req.body.psw
    }
    db.users.insert(newUser,function(err,result)
        {
            if(err)
            {
                console.log(err);
            } 
            res.redirect('/');

        });
}
);

app.use('/login',function(req,res)
{
    var username =req.body.un;
    var password = req.body.pw;
    db.users.findOne({user:username,pass:password},function(err,user)
    {
        if(err){console.log('no');return res.status(500).send();}
        if(!user){console.log('no no');return res.status(404).send();}
        return res.render('loggedIn.ejs')
    }
        );
    }
    

);

app.use('/loggedIn',function(req,res)
{
   res.render('loggedIn.ejs');
}
);

app.use('/addwork',function(req,res)
{
   res.render('addingwork.ejs');
}
);
app.use('/addtoportfolio',function(req,res)
{
    var namee =req.body.usrname;
    var comm = req.body.comment;

    db.portf.insert({name:namee,comment:comm},function(err,result)
        {
            if(err)
            {
                console.log(err);
            } 
            res.redirect('/');
        });
   
   
}
);

app.use('/viewport',function(req,res)
{
    /*res.render('portof.ejs',{
        title:'Portfolios',
        doneport:doneport
    });*/
    var myportfolios= new Array();
    var cursor= db.portf.find().forEach(function(item)
        {
            if(item != null)
               {
                myportfolios.push(item.name,item.comment); 
               }
           
        });
    res.render('portof.ejs',{
        title:'portfolios',
        myportfolios:myportfolios
    });

}
);

app.listen(port,function(){console.log('Server started on port '+port);});